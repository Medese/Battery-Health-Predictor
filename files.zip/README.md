# EV Battery Failure Predictor — Deployment

Deployable package for the EV Battery Failure MLP classifier: a training
notebook that saves the model, a FastAPI service with a simple web form,
and a Dockerfile to containerize it.

```
battery_failure_deployment/
├── 01_train_and_save_model.ipynb   # run cell-by-cell to train + save the model
├── app/
│   ├── main.py                     # FastAPI app (web form + JSON API)
│   ├── templates/
│   │   ├── index.html              # input form, built from the feature manifest
│   │   └── result.html             # prediction result page
│   └── static/
│       └── style.css
├── model/                          # filled in by the notebook
│   ├── model.joblib                 (created after training)
│   └── feature_manifest.json        (created after training)
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── .dockerignore
├── .gitignore
└── README.md
```

## 1. Train and save the model

1. Put `ev_battery_failure_dataset.csv` next to `01_train_and_save_model.ipynb`
   (or edit the path in the *Load data* cell).
2. Open the notebook (locally with Jupyter, or upload to Colab) and run
   every cell in order, top to bottom.
3. The last two cells save:
   - `model/model.joblib` — the full fitted `Pipeline` (imputation, scaling,
     one-hot encoding, and the `MLPClassifier`), so inference at serve time
     is identical to training.
   - `model/feature_manifest.json` — the exact numeric/categorical column
     names the model expects, the categorical values seen in training, and
     the recall-biased decision threshold chosen during evaluation.

If you ran the notebook somewhere other than this folder (e.g. Colab),
download `model.joblib` and `feature_manifest.json` and place both files
inside `battery_failure_deployment/model/` before continuing.

## 2. Run locally with Docker

From inside `battery_failure_deployment/`:

```bash
docker compose up --build
```

or without compose:

```bash
docker build -t ev-battery-failure-api .
docker run -p 8000:8000 -v "$(pwd)/model:/code/model" ev-battery-failure-api
```

Then open:
- **http://localhost:8000/** — the web form
- **http://localhost:8000/docs** — interactive Swagger/OpenAPI docs
- **http://localhost:8000/health** — health check

## 3. API usage

```bash
curl -X POST http://localhost:8000/api/predict \
  -H "Content-Type: application/json" \
  -d '{"state_of_charge_percent": 62, "internal_resistance_mohm": 45, "...": "..."}'
```

Response:

```json
{
  "failure_probability": 0.734,
  "prediction": "failure",
  "threshold_used": 0.219
}
```

Missing keys are treated as missing values and imputed the same way as
during training (median for numeric, "missing" category for categorical).
Call `GET /api/features` to get the exact list of expected feature names
and, for categorical ones, the values seen during training.

## 4. Run without Docker (optional, for development)

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

## 5. Push to a new GitHub repository

Create an empty repository on GitHub first (no README/license, so there's
no merge conflict), then from inside `battery_failure_deployment/`:

```bash
git init
git add .
git commit -m "Initial commit: EV battery failure predictor"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo-name>.git
git push -u origin main
```

If you'd rather create the GitHub repo from the command line with the
`gh` CLI instead of the web UI:

```bash
gh repo create <your-repo-name> --public --source=. --remote=origin --push
```

### Note on the trained model file

`model.joblib` can be a fairly large binary. The `.gitignore` in this repo
leaves it trackable by default; if it turns out to be too large for a
normal git push (GitHub's soft limit is ~50MB, hard limit 100MB), either:
- use [Git LFS](https://git-lfs.com/): `git lfs track "model/*.joblib"`, or
- uncomment the `model/*.joblib` line in `.gitignore` and instead attach
  the model as a GitHub Release asset or pull it from cloud storage on
  container startup.
