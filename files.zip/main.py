"""
EV Battery Failure Predictor - FastAPI service.

Loads the sklearn Pipeline (preprocessing + MLPClassifier) saved by
01_train_and_save_model.ipynb, together with a feature manifest that
records exactly which columns the pipeline expects. The web form and
the JSON API are both generated from that manifest, so this file does
not need to hardcode any of the 55 EV battery feature names.
"""

import json
from pathlib import Path

import joblib
import pandas as pd
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

BASE_DIR = Path(__file__).resolve().parent
MODEL_DIR = BASE_DIR.parent / "model"

app = FastAPI(
    title="EV Battery Failure Predictor",
    description="Predicts battery failure risk from vehicle telemetry features.",
    version="1.0.0",
)

templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")

pipeline = None
manifest = None


@app.on_event("startup")
def load_artifacts() -> None:
    """Load the trained pipeline and feature manifest into memory."""
    global pipeline, manifest

    model_path = MODEL_DIR / "model.joblib"
    manifest_path = MODEL_DIR / "feature_manifest.json"

    if not model_path.exists() or not manifest_path.exists():
        raise RuntimeError(
            f"Could not find model artifacts in {MODEL_DIR}.\n"
            "Run 01_train_and_save_model.ipynb first, then copy the "
            "resulting model.joblib and feature_manifest.json into the "
            "model/ folder before starting the API."
        )

    pipeline = joblib.load(model_path)
    with open(manifest_path) as f:
        manifest = json.load(f)


def _coerce_row(values: dict) -> pd.DataFrame:
    """Build a single-row DataFrame matching the columns the pipeline expects."""
    row = {}

    for col in manifest["numeric_cols"]:
        raw = values.get(col)
        if raw in (None, ""):
            row[col] = None
        else:
            try:
                row[col] = float(raw)
            except (TypeError, ValueError):
                raise ValueError(f"'{col}' must be numeric, got: {raw!r}")

    for col in manifest["categorical_cols"]:
        raw = values.get(col)
        row[col] = raw if raw not in (None, "") else None

    return pd.DataFrame([row])


def _predict(values: dict):
    X = _coerce_row(values)
    proba = float(pipeline.predict_proba(X)[:, 1][0])
    threshold = manifest["chosen_threshold"]
    prediction = int(proba >= threshold)
    return proba, prediction, threshold


@app.get("/", response_class=HTMLResponse)
def form_page(request: Request):
    """Simple HTML form built dynamically from the feature manifest."""
    return templates.TemplateResponse(
        "index.html",
        {
            "request": request,
            "numeric_cols": manifest["numeric_cols"],
            "categorical_cols": manifest["categorical_cols"],
            "categorical_options": manifest.get("categorical_options", {}),
        },
    )


@app.post("/predict", response_class=HTMLResponse)
async def predict_form(request: Request):
    """Handle the HTML form submission and render a result page."""
    form = await request.form()
    values = dict(form)

    try:
        proba, prediction, threshold = _predict(values)
    except ValueError as exc:
        return templates.TemplateResponse(
            "index.html",
            {
                "request": request,
                "numeric_cols": manifest["numeric_cols"],
                "categorical_cols": manifest["categorical_cols"],
                "categorical_options": manifest.get("categorical_options", {}),
                "error": str(exc),
                "submitted": values,
            },
            status_code=400,
        )

    return templates.TemplateResponse(
        "result.html",
        {
            "request": request,
            "proba_pct": round(proba * 100, 2),
            "label": "FAILURE RISK" if prediction else "HEALTHY",
            "is_failure": bool(prediction),
            "threshold": round(threshold, 3),
        },
    )


@app.post("/api/predict")
async def predict_api(payload: dict):
    """
    JSON API endpoint.

    Send a JSON object whose keys are feature names (see GET /api/features
    for the exact list) and whose values are the corresponding readings.
    Missing keys are treated as missing values and imputed like in training.
    """
    proba, prediction, threshold = _predict(payload)
    return {
        "failure_probability": round(proba, 6),
        "prediction": "failure" if prediction else "healthy",
        "threshold_used": threshold,
    }


@app.get("/api/features")
def list_features():
    """Returns the exact feature names/types the model expects."""
    return {
        "numeric_cols": manifest["numeric_cols"],
        "categorical_cols": manifest["categorical_cols"],
        "categorical_options": manifest.get("categorical_options", {}),
    }


@app.get("/health")
def health():
    return {"status": "ok", "model_loaded": pipeline is not None}
